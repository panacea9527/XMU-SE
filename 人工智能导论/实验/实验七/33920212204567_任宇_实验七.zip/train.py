# 导入所需库
import tensorflow as tf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import cv2
from tensorflow import keras
import sys

# 打印库版本，确保环境无误
print(tf.__version__)
print(sys.version_info)
for module in [np, pd, keras]:
    print(module.__name__, module.__version__)

# 设置数据路径
train_dir = './train'
valid_dir = './validation'
test_dir = './test'

# 设置模型参数
height = 128
width = 128
channel = 3
batch_size = 64
valid_batch_size = 64
num_classes = 2
epochs = 100

# 定义训练模型的函数
def trainModel(model, train_generator, valid_generator, callbacks):
    history = model.fit(
        train_generator,
        epochs=epochs,
        validation_data=valid_generator,
        callbacks=callbacks
    )
    return history

# 定义绘制学习曲线的函数
def plot_learning_curves(history, label, epochs, min_value, max_value):
    data = {}
    data[label] = history.history[label]
    data['val_' + label] = history.history['val_' + label]
    pd.DataFrame(data).plot(figsize=(8, 5))
    plt.grid(True)
    plt.axis([0, epochs, min_value, max_value])
    plt.show()

# 定义使用训练好的模型进行预测并分类图片的函数
def predictModel(model, output_model_file):
    model.load_weights(output_model_file)  # 加载模型权重
    os.makedirs('./save/cat', exist_ok=True)  # 创建保存分类结果的目录
    os.makedirs('./save/dog', exist_ok=True)

    test_dir = './test/'  # 设置测试目录
    for i in range(1, 12500):  # 遍历图片
        img_name = f'{test_dir}{i}.jpg'
        img = cv2.imread(img_name)  # 读取图片
        img = cv2.resize(img, (width, height))  # 调整图片大小
        img_arr = img / 255.0  # 归一化
        img_arr = img_arr.reshape((1, width, height, 3))  # 调整数组形状
        pre = model.predict(img_arr)  # 进行预测
        if pre[0][0] > pre[0][1]:
            cv2.imwrite(f'./save/cat/{i}.jpg', img)  # 保存为猫的图片
            print(img_name, ' is classified as Cat.')
        else:
            cv2.imwrite(f'./save/dog/{i}.jpg', img)  # 保存为狗的图片
            print(img_name, ' is classified as Dog.')

if __name__ == '__main__':
    # 数据增强处理
    train_datagen = keras.preprocessing.image.ImageDataGenerator(
        rescale=1. / 255,
        rotation_range=40,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest',
    )

    # 生成训练数据
    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=(width, height),
        batch_size=batch_size,
        seed=7,
        shuffle=True,
        class_mode='categorical'
    )

    # 生成验证数据
    valid_datagen = keras.preprocessing.image.ImageDataGenerator(
        rescale=1. / 255,
    )

    valid_generator = valid_datagen.flow_from_directory(
        valid_dir,
        target_size=(width, height),
        batch_size=valid_batch_size,
        seed=7,
        shuffle=False,
        class_mode="categorical"
    )

    # 构建模型
    model = keras.models.Sequential([
        keras.layers.Conv2D(32, 3, padding='same', activation='relu', input_shape=[width, height, channel]),
        keras.layers.Conv2D(32, 3, padding='same', activation='relu'),
        keras.layers.MaxPool2D(2),
        keras.layers.Conv2D(64, 3, padding='same', activation='relu'),
        keras.layers.Conv2D(64, 3, padding='same', activation='relu'),
        keras.layers.MaxPool2D(2),
        keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        keras.layers.MaxPool2D(2),
        keras.layers.Flatten(),
        keras.layers.Dense(128, activation='relu'),
        keras.layers.Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()  # 显示模型结构

    # 设置模型保存路径
    logdir = './graph_def_and_weights'
    os.makedirs(logdir, exist_ok=True)
    output_model_file = os.path.join(logdir, "catDog_weights.h5")

    mode = input('选择模式：1.训练 2.预测\n请输入数字：')  # 用户选择模式
    if mode == '1':
        callbacks = [
            keras.callbacks.TensorBoard(logdir),
            keras.callbacks.ModelCheckpoint(output_model_file, save_best_only=True, save_weights_only=True),
            keras.callbacks.EarlyStopping(patience=5, min_delta=1e-3)
        ]
        history = trainModel(model, train_generator, valid_generator, callbacks)
        plot_learning_curves(history, 'accuracy', epochs, 0, 1)
        plot_learning_curves(history, 'loss', epochs, 0, 5)
    elif mode == '2':
        predictModel(model, output_model_file)
    else:
        print('请输入正确的数字。')

    print('结束！')
