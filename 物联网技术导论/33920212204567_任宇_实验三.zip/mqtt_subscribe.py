import random  
from paho.mqtt import client as mqtt_client
import json  

# MQTT服务器的配置参数
broker = '47.106.117.242' 
port = 1883  
topic = "weather/sensor" 
client_id = f'subscribe-{random.randint(0, 100)}' 
msg_received = 0  

def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        # 连接事件的回调函数
        if rc == 0:
            print("Connected to MQTT Broker!")  # 连接成功
        else:
            print(f"Failed to connect, return code {rc}\n")  # 连接失败

    client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION1,client_id)  # 创建MQTT客户端实例
    client.on_connect = on_connect  # 设置连接事件的回调函数
    client.connect(broker, port)  # 连接到MQTT代理服务器
    return client

def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        global msg_received  
        try:
            summary = json.loads(msg.payload)
            if "total_msgs" in summary and "total_time" in summary:
                # 计算吞吐量（消息每秒）
                throughput = summary["total_msgs"] / summary["total_time"]
                # 计算丢包率
                packet_loss_rate = ((summary["total_msgs"] - msg_received) / summary["total_msgs"]) * 100
                # 打印计算结果
                print(f"Throughput: {throughput:.2f} messages/second")
                print(f"Packet Loss Rate: {packet_loss_rate:.2f}%")
                client.disconnect()  # 收到总结消息后断开连接
        except json.JSONDecodeError:
            # 如果解析JSON失败，说明是正常传感器数据消息
            msg_received += 1
            print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic") # 打印接收到的消息和主题

    client.subscribe(topic)  # 订阅指定的MQTT主题
    client.on_message = on_message  # 设置消息接收的回调函数

def run():
    client = connect_mqtt()  # 连接到MQTT服务器
    subscribe(client)  # 订阅MQTT主题
    client.loop_forever()  # 进入循环，等待接收消息

if __name__ == '__main__':
    run()  
