import random
from paho.mqtt import client as mqtt_client 
import json  
import timeit 

# MQTT服务器的配置参数
broker = '47.106.117.242'  # MQTT代理服务器的IP地址
port = 1883  # MQTT使用的端口号，默认为1883
topic = "weather/sensor"  # MQTT主题，用于发布消息
client_id = f'python-mqtt-{random.randint(0, 1000)}'  # 客户端ID，随机生成以避免冲突
max_msgs = 100000  

def generate_weather_data():
    temperature = random.uniform(-20, 40)  # 生成随机温度值
    humidity = random.uniform(0, 100)  # 生成随机湿度值
    return f"Temperature: {temperature:.2f} C, Humidity: {humidity:.2f}%"

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        # 连接事件的回调函数
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print(f"Failed to connect, return code {rc}\n")

    client = mqtt_client.Client(mqtt_client.CallbackAPIVersion.VERSION1,client_id)  # 创建MQTT客户端实例
    client.on_connect = on_connect  # 设置连接事件的回调函数
    client.connect(broker, port)  # 连接到MQTT代理服务器
    return client

def publish(client):
    start_time = timeit.default_timer()  
    msg_count = 0
    while msg_count < max_msgs:
        msg = generate_weather_data()  # 生成模拟的气象数据消息
        result = client.publish(topic, msg)  # 发布消息
        status = result[0]
        if status == 0:
            print(f"Send `{msg}` to topic `{topic}`")
        else:
            print(f"Failed to send message to topic {topic}")
        msg_count += 1  
    total_time = timeit.default_timer() - start_time
    # 发送一条总结消息，包含发送的总消息数和总耗时
    summary_msg = json.dumps({"total_msgs": max_msgs, "total_time": total_time})
    client.publish(topic, summary_msg)
    print(f"Sent {msg_count} messages in {total_time:.2f} seconds.")

def run():
    client = connect_mqtt()  # 连接到MQTT服务器
    client.loop_start()  # 开始MQTT客户端循环
    publish(client)  # 发布消息
    client.loop_stop()  # 停止MQTT客户端循环

if __name__ == '__main__':
    run()
