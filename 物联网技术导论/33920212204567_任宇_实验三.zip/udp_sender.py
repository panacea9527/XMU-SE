import socket
import random  
import json  
import timeit 

host = '192.168.3.17'  # 目标主机的IP地址
port = 12345  # 目标端口号
max_msgs = 100000  # 要发送的消息总数，这里设置为10万条消息

def generate_weather_data(index):
    temperature = random.uniform(-20, 40)  # 生成-20到40之间的随机温度值
    humidity = random.uniform(0, 100)  # 生成0到100之间的随机湿度值
    return f"Message {index}: Temperature: {temperature:.2f} C, Humidity: {humidity:.2f}%"  # 返回格式化的消息字符串

def send_udp_messages():
    """
    发送UDP消息。
    这个函数创建一个UDP socket，循环发送指定数量的模拟气象数据消息，
    然后发送一个包含总消息数和总耗时的总结消息。
    """
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock: # 创建一个UDP socket
        start_time = timeit.default_timer()  
        for i in range(max_msgs): 
            msg = generate_weather_data(i + 1) 
            sock.sendto(msg.encode(), (host, port))  # 发送消息

        total_time = timeit.default_timer() - start_time  
        summary_message = json.dumps({"total_msgs": max_msgs, "total_time": total_time})
        sock.sendto(summary_message.encode(), (host, port))  
        print(f"Sent {max_msgs} messages in {total_time:.2f} seconds.")  

if __name__ == '__main__':
    send_udp_messages()

