import socket 
import json  

host = '192.168.3.17'  # 接收器监听的IP地址
port = 12345  # 接收器监听的端口号
msg_received = 0  

def receive_udp_messages():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:  # 创建一个UDP socket
        sock.bind((host, port))  # 绑定socket到指定的IP地址和端口
        print(f"Listening on {host}:{port}")  

        global msg_received  
        while True:  # 无限循环，直到接收到总结消息并处理后退出
            data, addr = sock.recvfrom(1024)  
            msg_received += 1  

            try:
                summary = json.loads(data.decode())
                # 如果解析成功且消息包含总消息数和总耗时的信息
                if "total_msgs" in summary and "total_time" in summary:
                    # 计算吞吐量（消息每秒）
                    throughput = summary["total_msgs"] / summary["total_time"]
                    # 计算丢包率
                    packet_loss_rate = ((summary["total_msgs"] - (msg_received - 1)) / summary["total_msgs"]) * 100
                    print(f"Throughput: {throughput:.2f} messages/second")
                    print(f"Packet Loss Rate: {packet_loss_rate:.2f}%")
                    break 
            except json.JSONDecodeError:
                # 如果解析JSON失败，说明是正常的气象数据消息
                print(f"Received `{data.decode()}` from {addr}")  # 打印接收到的消息和发送者地址

if __name__ == '__main__':
    receive_udp_messages() 
