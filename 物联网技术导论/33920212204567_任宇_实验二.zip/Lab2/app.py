from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)

@app.route('/data')
def get_data():
    connection = mysql.connector.connect(
        host='localhost',
        database='sensor_data',
        user='root',
        password='renyu20031205.'
    )
    cursor = connection.cursor()
    cursor.execute('SELECT temperature, humidity, timestamp FROM weather_data ORDER BY timestamp')
    result = cursor.fetchall()

    data = []
    for row in result:
        data.append({'temperature': row[0], 'humidity': row[1], 'timestamp': str(row[2])})

    cursor.close()
    connection.close()

    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
