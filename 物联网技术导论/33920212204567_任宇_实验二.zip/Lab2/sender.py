import socket
import time
import random
import json

def generate_weather_data():
    temperature = random.randint(-10, 40)  # 模拟温度，范围从-10到40摄氏度
    humidity = random.randint(20, 100)  # 模拟湿度，范围从20%到100%
    data = {
        "temperature": temperature,
        "humidity": humidity
    }
    return json.dumps(data)

def send_udp_message(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        while True:
            message = generate_weather_data()
            sock.sendto(message.encode(), (host, port))
            print(f"Sent: {message}")
            time.sleep(5)  # 每5秒发送一次数据

if __name__ == "__main__":
    send_udp_message("127.0.0.1", 5005)
