import socket
import mysql.connector
import json

def insert_into_database(temperature, humidity):
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='sensor_data',
            user='root',
            password='renyu20031205.'
        )
        cursor = connection.cursor()
        query = "INSERT INTO weather_data (temperature, humidity) VALUES (%s, %s)"
        cursor.execute(query, (temperature, humidity))
        connection.commit()
        print(f"Data inserted successfully: Temperature={temperature}, Humidity={humidity}")
    except mysql.connector.Error as error:
        print(f"Failed to insert data into MySQL table {error}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

def start_udp_server(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind((host, port))
        print(f"Listening on {host}:{port}")
        while True:
            data, addr = sock.recvfrom(1024) 
            data_decoded = data.decode()
            print(f"Received from {addr}: {data_decoded}")
            data_json = json.loads(data_decoded)
            temperature = data_json['temperature']
            humidity = data_json['humidity']
            insert_into_database(temperature, humidity)

if __name__ == "__main__":
    start_udp_server("127.0.0.1", 5005)
