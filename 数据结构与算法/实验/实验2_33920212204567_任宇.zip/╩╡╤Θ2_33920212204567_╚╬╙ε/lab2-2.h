#define _CRT_SECURE_NO_WARNINGS
#include  <stdio.h>
#include  <string.h>
#include  <malloc.h>
#include <windows.h>

#define N 30
#define M 2 * N - 1
#define MAX 999999

//�������������Ͷ���
typedef struct huffmantree
{
	int weight;
	int parent;
	int lchild;
	int rchlid;
	char s;
}HuffmanTreeNode, HuffmanTree[M + 1];

//��ѡȨ����С��parentΪ��������ڵ�
void Select(HuffmanTree ht, int n, int* s1, int* s2)
{
	int i = 0;
	int min1 = MAX;
	int min2 = MAX;
	*s1 = *s2 = 0;
	for (i = 1; i <= n; i++)
	{
		if (ht[i].parent == 0)
		{
			if (ht[i].weight < min1)
			{
				min2 = min1;    //min1��ʱΪ�ڶ�С����˰�min1����min2
				min1 = ht[i].weight;
				*s2 = *s1;
				*s1 = i;
			}
			else if (ht[i].weight < min2)
			{
				min2 = ht[i].weight;
				*s2 = i;
			}
		}
	}
}

//������������
void CreateHuffmanTree(HuffmanTree ht, int w[], int n, char s[])
{
	int i = 0;
	for (i = 1; i <= n; i++)
	{
		ht[i].weight = w[i - 1];
		ht[i].s = s[i - 1];
		ht[i].lchild = 0;
		ht[i].rchlid = 0;
		ht[i].parent = 0;
	}
	int m = 2 * n - 1;
	for (i = n + 1; i <= m; i++)
	{
		ht[i].weight = 0;
		ht[i].lchild = 0;
		ht[i].rchlid = 0;
		ht[i].parent = 0;
	}
	int s1, s2;
	for (i = n + 1; i <= m; i++)
	{
		Select(ht, i - 1, &s1, &s2);
		ht[i].weight = ht[s1].weight + ht[s2].weight;
		ht[i].lchild = s1;
		ht[i].rchlid = s2;
		ht[s1].parent = i;
		ht[s2].parent = i;
	}
}

//����������
void CreateHuffmanCode(HuffmanTree ht, int n, char str[], char** hc)
{
	char* cd = (char*)malloc(n * sizeof(char));
	cd[n - 1] = '\0';
	for (int i = 1; i <= n; i++)
	{
		int start = n - 1;
		int now = i;
		int p = ht[i].parent;
		while (p != 0)
		{
			start--;
			if (ht[p].lchild == now)
			{
				cd[start] = '0';
			}
			else
			{
				cd[start] = '1';
			}
			now = p;
			p = ht[p].parent;
		}
		hc[i] = (char*)malloc((n - start) * sizeof(char));
		strcpy(hc[i], &cd[start]);
	}
	free(cd);
}

void printHuffmanTree(HuffmanTree ht, char** hc, int index)
{
	if (index >= 1)
	{
		if (ht[index].lchild == 0 && ht[index].rchlid == 0)
		{
			printf("%c:%s\n", ht[index].s, hc[index]);
			return;
		}
		printHuffmanTree(ht, hc, ht[index].lchild);
		printHuffmanTree(ht, hc, ht[index].rchlid);
	}
}

void HuffmanDecoding(HuffmanTree ht, int n, char* pwd)
{
	printf("original:");
	int len = strlen(pwd);
	int i = 0;
	int node = 2 * n - 1;
	while (i < len)
	{
		if (pwd[i] == '0')
		{
			node = ht[node].lchild;
			i++;
			if (ht[node].lchild == 0 && ht[node].rchlid == 0)
			{
				printf("%c", ht[node].s);
				node = 2 * n - 1;
			}
		}
		if (pwd[i] == '1')
		{
			node = ht[node].rchlid;
			i++;
			if (ht[node].lchild == 0 && ht[node].rchlid == 0)
			{
				printf("%c", ht[node].s);
				node = 2 * n - 1;
			}
		}
	}
	printf("\n");
}

void HuffmanRecoding(HuffmanTree ht, int n, char* s, char** hc)
{
	int len = strlen(s);
	int i = 0;
	printf("���ַ�������Ϊ��");
	while (i < len)
	{
		for (int j = 1; j <= n; j++)
		{
			if (ht[j].s == s[i])
			{
				printf("%s", hc[j]);
				i++;
				break;
			}
		}
	}
	printf("\n");
}


void Menu()
{
	printf("************************\n");
	printf("**1.������������********\n");
	printf("**2.�鿴���������ڵ�ֵ**\n");
	printf("**3.�鿴�ַ���Ӧ����****\n");
	printf("**4.�����ַ���**********\n");
	printf("**5.������**************\n");
	printf("**6.�˳�****************\n");
}


