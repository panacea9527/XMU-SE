#include "lab2-1.h"
int main()
{   
    menu();
    int x = 0;
    BiTree t = NULL;
    while (scanf("%d", &x) != EOF)
    {
        switch (x)
        {
        case 1:
            getchar();
            printf("�������������У�\n");
            t = CreateBiTree();
            break;
        case 2:
            PreOrder(t);
            printf("\n");
            break;
        case 3:
            InOrder(t);
            printf("\n");
            break;
        case 4:
            PostOrder(t);
            printf("\n");
            break;
        case 5:
            return 0;
        default:
            printf("����������������룡\n");
        }
    }
    return 0;
}

