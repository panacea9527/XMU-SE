#pragma once
#define _CRT_SECURE_NO_WARNINGS
//ͷ�ļ�
#include<stdio.h>
#include <string.h>

void swap(char* a, char* b)
{
	char temp = *a;
	*a = *b;
	*b = temp;
}

void sort(char* a)
{
	int i = 0;
	int j = 0;
	int k = strlen(a) - 1;
	while (j <= k)
	{
		if (a[j] == 'R')
		{
			swap(&a[i++], &a[j++]);
		}
		else if (a[j] == 'B')
		{
			swap(&a[j], &a[k--]);
		}
		else
			j++;
	}
}