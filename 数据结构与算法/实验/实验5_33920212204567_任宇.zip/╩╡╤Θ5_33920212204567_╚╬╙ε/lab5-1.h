#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include<math.h>

#define MAX 10


int binary_search(int a[], int k, int s)
{
	int left = 0;
	int right = s - 1;
	while (left <= right)
	{
		int mid = (left + right) / 2;
		if (k < a[mid])
		{
			right = mid - 1;
		}
		else if (k > a[mid])
		{
			left = mid + 1;
		}
		else
		{
			return mid;
		}
	}
	return -1;

}