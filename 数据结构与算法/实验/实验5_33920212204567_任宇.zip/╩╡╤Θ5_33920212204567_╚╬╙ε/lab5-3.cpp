#include "lab5-3.h"

int main()
{
    NameArray NameList = NULL;//����
    Hashlist HashTable = NULL;//��ϣ��
    int choice = 1;
    InitNameList(NameList);
    CreatHush(HashTable, NameList);
    while (choice) 
    {
        menu();
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:Print_NameList(NameList); break;
        case 2:Print_Hash(HashTable); break;
        case 3:Search(HashTable); break;
        case 0:printf("���˳�\n"); break;
        default: printf("EROOR INPUT!\a\n"); break;
        }
    }
    return 0;
}

