#ifndef PL0PCODE_H
#define PL0PCODE_H

enum class Operator {
    INT, CAL, LIT, LOD, STO, JMP, JPC, OPR
};


class PL0Pcode {
private:
    Operator F;
    int L;
    int A;

public:
    PL0Pcode(Operator _F, int _L, int _A)
        : F(_F), L(_L), A(_A) {}

    // ���ú���
    void setF(Operator _F) {
        F = _F;
    }

    void setL(int _L) {
        L = _L;
    }

    void setA(int _A) {
        A = _A;
    }

    // ��ȡ����
    Operator getF() const {
        return F;
    }

    int getL() const {
        return L;
    }

    int getA() const {
        return A;
    }
};

#endif // PL0PCODE_H
