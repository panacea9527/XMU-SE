#ifndef PL0INTERPRETER_H
#define PL0INTERPRETER_H

#include <vector>
#include <string>
#include <iostream>
#include <memory>
#include "PL0Pcode.h"
#include "PL0PcodeManager.h"

class PL0Interpreter {
private:
    static const int STACK_SIZE = 1000;
    int dataStack[STACK_SIZE];
    std::vector<std::shared_ptr<PL0Pcode>> pcode;
    std::vector<int> input;
    int inputPtr = 0;
    std::vector<std::string> output;

public:
    PL0Interpreter() = default;

    PL0Interpreter(const std::vector<int>& _input)
        : input(_input), output(std::vector<std::string>()) {}

    void setAllPcode(const std::shared_ptr<PL0PcodeManager>& allPcode) {
        pcode = allPcode->getAllPcode();
    }

    std::vector<std::string> getOutput() const {
        return output;
    }

    void interpreter() {
        int pc = 0; // �����������ָ����һ��ָ��
        int base = 0; // ��ǰ����ַ
        int top = 0; // ��������ջջ��

        do {
            auto currentPcode = pcode[pc];
            pc++;
            switch (currentPcode->getF()) {
            case Operator::LIT:
                dataStack[top++] = currentPcode->getA();
                break;
            case Operator::OPR:
                switch (currentPcode->getA()) {
                case 0:
                    top = base;
                    pc = dataStack[base + 2];
                    base = dataStack[base];
                    break;
                case 1:
                    dataStack[top - 1] = -dataStack[top - 1];
                    break;
                case 2:
                    dataStack[top - 2] += dataStack[top - 1];
                    top--;
                    break;
                case 3:
                    dataStack[top - 2] -= dataStack[top - 1];
                    top--;
                    break;
                case 4:
                    dataStack[top - 2] *= dataStack[top - 1];
                    top--;
                    break;
                case 5:
                    dataStack[top - 2] /= dataStack[top - 1];
                    top--;
                    break;
                case 6:
                    dataStack[top - 1] %= 2;
                    break;
                case 7:
                    break;
                case 8:
                    dataStack[top - 2] = dataStack[top - 2] == dataStack[top - 1];
                    top--;
                    break;
                case 9:
                    dataStack[top - 2] = dataStack[top - 2] != dataStack[top - 1];
                    top--;
                    break;
                case 10:
                    dataStack[top - 2] = dataStack[top - 2] < dataStack[top - 1];
                    top--;
                    break;
                case 11:
                    dataStack[top - 2] = dataStack[top - 2] >= dataStack[top - 1];
                    top--;
                    break;
                case 12:
                    dataStack[top - 2] = dataStack[top - 2] > dataStack[top - 1];
                    top--;
                    break;
                case 13:
                    dataStack[top - 2] = dataStack[top - 2] <= dataStack[top - 1];
                    top--;
                    break;
                case 14:
                    std::cout << dataStack[top - 1] << " ";
                    break;
                case 15:
                    std::cout << std::endl;
                    break;
                case 16:
                    std::cout << "please input a number" << std::endl;
                    std::cin >> dataStack[top++];
                    break;
                }
                break;
            case Operator::LOD:
                dataStack[top++] = dataStack[currentPcode->getA() + getBase(base, currentPcode->getL())];
                break;
            case Operator::STO:
                dataStack[currentPcode->getA() + getBase(base, currentPcode->getL())] = dataStack[--top];
                break;
            case Operator::CAL:
                dataStack[top] = base;
                dataStack[top + 1] = getBase(base, currentPcode->getL());
                dataStack[top + 2] = pc;
                base = top;
                pc = currentPcode->getA();
                break;
            case Operator::INT:
                top += currentPcode->getA();
                break;
            case Operator::JMP:
                pc = currentPcode->getA();
                break;
            case Operator::JPC:
                if (dataStack[--top] == 0) {
                    pc = currentPcode->getA();
                }
                break;
            }
        } while (pc != 0);
    }

private:
    int getBase(int nowBp, int lev) const {
        int oldBp = nowBp;
        while (lev > 0) {
            oldBp = dataStack[oldBp + 1];
            lev--;
        }
        return oldBp;
    }
};

#endif // PL0INTERPRETER_H
#pragma once
