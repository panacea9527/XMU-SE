#ifndef PL0LEXANALYSIS_H
#define PL0LEXANALYSIS_H

#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <memory>
#include "PL0Token.h"

class PL0LexAnalysis {
private:
    std::vector<std::string> keyWords = {
        "begin", "end", "if", "then", "else", "const", "procedure", "var", "do", "while", "call", "read", "write", "odd", "repeat", "until"
    };

    std::vector<std::shared_ptr<PL0Token>> allToken; // ������з���������token
    char ch = ' '; // ��ǰ�ַ� 
    size_t searchPtr = 0; // ָ��ǰ�ַ���ָ��
    std::vector<char> buffer; // �������Դ����
    int line = 1; // ��ǰ��
    std::string strToken; // ��ǰ���ڽ��дʷ��������ַ���

public:
    PL0LexAnalysis(const std::string& filename) {
        init();
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error opening file: " << filename << std::endl;
            return;
        }

        std::string temp1, temp2;
        while (std::getline(file, temp1)) {
            temp2 += temp1 + '\n';
        }
        buffer.assign(temp2.begin(), temp2.end());
        file.close();

        doAnalysis();
    }

    std::vector<std::shared_ptr<PL0Token>> getAllToken() const {
        return allToken;
    }

private:
    void doAnalysis() {
        while (searchPtr < buffer.size()) {
            allToken.push_back(analysis());
        }
    }

    std::shared_ptr<PL0Token> analysis() {
        strToken.clear();
        getChar();
        while ((ch == ' ' || ch == '\n' || ch == '\t' || ch == '\0') && searchPtr < buffer.size()) {
            if (ch == '\n') {
                line++;
            }
            getChar();
        }
        if (ch == '$' && searchPtr >= buffer.size()) { // �����ļ�ĩβ
            return std::make_shared<PL0Token>(PL0SymType::END_OF_FILE, line, "-1");
        }
        if (isLetter()) { // ��λΪ��ĸ������Ϊ�����ֻ��߱�����
            while (isLetter() || isDigit()) {
                strToken += ch;
                getChar();
            }
            retract();
            for (size_t i = 0; i < keyWords.size(); i++) {
                if (strToken == keyWords[i]) { // ˵���Ǳ�����
                    return std::make_shared<PL0Token>(static_cast<PL0SymType>(i), line, "-");
                }
            }
            // ���Ǳ����֣���Ϊ��ʶ������Ҫ����ֵ
            return std::make_shared<PL0Token>(PL0SymType::SYM, line, strToken);
        }
        else if (isDigit()) { // ��λΪ���֣���Ϊ����
            while (isDigit()) {
                strToken += ch;
                getChar();
            }
            retract();
            return std::make_shared<PL0Token>(PL0SymType::CONST, line, strToken);
        }
        else if (ch == '=') { // �Ⱥ�
            return std::make_shared<PL0Token>(PL0SymType::EQU, line, "-");
        }
        else if (ch == '+') { // �Ӻ�
            return std::make_shared<PL0Token>(PL0SymType::ADD, line, "-");
        }
        else if (ch == '-') { // ����
            return std::make_shared<PL0Token>(PL0SymType::SUB, line, "-");
        }
        else if (ch == '*') { // �˺�
            return std::make_shared<PL0Token>(PL0SymType::MUL, line, "-");
        }
        else if (ch == '/') { // ����
            return std::make_shared<PL0Token>(PL0SymType::DIV, line, "-");
        }
        else if (ch == '<') { // С�ڻ򲻵��ڻ�С�ڵ���
            getChar();
            if (ch == '=') {
                return std::make_shared<PL0Token>(PL0SymType::LESE, line, "-");
            }
            else if (ch == '>') {
                return std::make_shared<PL0Token>(PL0SymType::NEQE, line, "-");
            }
            else {
                retract();
                return std::make_shared<PL0Token>(PL0SymType::LES, line, "-");
            }
        }
        else if (ch == '>') { // ���ڻ���ڵ���
            getChar();
            if (ch == '=') {
                return std::make_shared<PL0Token>(PL0SymType::LARE, line, "-");
            }
            else {
                retract();
                return std::make_shared<PL0Token>(PL0SymType::LAR, line, "-");
            }
        }
        else if (ch == ',') { // ����
            return std::make_shared<PL0Token>(PL0SymType::COMMA, line, "-");
        }
        else if (ch == ';') { // �ֺ�
            return std::make_shared<PL0Token>(PL0SymType::SEMIC, line, "-");
        }
        else if (ch == '.') { // ��
            return std::make_shared<PL0Token>(PL0SymType::POI, line, "-");
        }
        else if (ch == '(') { // ������
            return std::make_shared<PL0Token>(PL0SymType::LBR, line, "-");
        }
        else if (ch == ')') { // ������
            return std::make_shared<PL0Token>(PL0SymType::RBR, line, "-");
        }
        else if (ch == ':') { // ��ֵ��
            getChar();
            if (ch == '=') {
                return std::make_shared<PL0Token>(PL0SymType::CEQU, line, "-");
            }
            else {
                retract();
                return std::make_shared<PL0Token>(PL0SymType::COL, line, "-");
            }
        }
        return std::make_shared<PL0Token>(PL0SymType::END_OF_FILE, line, "-");
    }

    void init() {
        allToken = std::vector<std::shared_ptr<PL0Token>>();
    }

    char getChar() {
        if (searchPtr < buffer.size()) {
            ch = buffer[searchPtr];
            searchPtr++;
        }
        else {
            ch = '$';
        }
        return ch;
    }

    void retract() {
        searchPtr--;
        ch = ' ';
    }

    bool isLetter() const {
        return std::isalpha(ch);
    }

    bool isDigit() const {
        return std::isdigit(ch);
    }
};

#endif // PL0LEXANALYSIS_H
#pragma once
