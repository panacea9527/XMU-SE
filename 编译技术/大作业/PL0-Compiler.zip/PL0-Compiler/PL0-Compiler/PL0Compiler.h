#ifndef PL0COMPILER_H
#define PL0COMPILER_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <memory>
#include "PL0SyntaxAnalyzer.h"

class PL0Compiler {
private:
    std::shared_ptr<PL0SyntaxAnalyzer> gsa;
    std::vector<std::shared_ptr<PL0Token>> allToken;
    std::vector<std::shared_ptr<PL0Symbol>> allSymbol;
    std::vector<std::shared_ptr<PL0Pcode>> allPcode;
    std::vector<std::string> errors;
    std::string consoleMessage;
    bool success = false;

public:
    PL0Compiler() = default;

    void compile(const std::string& filename) {
        gsa = std::make_shared<PL0SyntaxAnalyzer>(filename);
        clean();
        if (success = gsa->compile()) {
            displayAllSymbol();
            displayAllPcode();
            consoleMessage += "compile succeed!\n";
            std::cout << consoleMessage << std::endl;
        }
        else {
            displayErrorMessage();
            consoleMessage += "compile failed!";
            std::cout << consoleMessage << std::endl;
        }
    }

private:
    void clean() {
        allToken.clear();
        allSymbol.clear();
        allPcode.clear();
        consoleMessage.clear();
        success = false;
    }

    void displayErrorMessage() {
        consoleMessage.clear();
        errors = gsa->getErrorMessage();
        for (const auto& error : errors) {
            consoleMessage += error + "\n";
        }
    }

    void displayAllToken() {
        allToken = gsa->getAllToken();
        std::cout << "Token Table:\n";
        std::cout << "Type\tLine\tValue\n";
        for (const auto& token : allToken) {
            std::cout << static_cast<int>(token->getSt()) << "\t" << token->getLine() << "\t" << token->getValue() << "\n";
        }
        std::cout << std::endl;
    }

    void displayAllSymbol() {
        allSymbol = gsa->getPL0SymbolTable();
        std::cout << "Symbol Table:\n";
        std::cout << "Name\tType\tValue\tLevel\tAddress\n";
        for (const auto& symbol : allSymbol) {
            std::cout << symbol->getName() << "\t" << symbol->getType() << "\t" << symbol->getValue() << "\t" << symbol->getLevel() << "\t" << symbol->getAddress() << "\n";
        }
        std::cout << std::endl;
    }

    void displayAllPcode() {
        allPcode = gsa->getAllPcode();
        std::cout << "Pcode Table:\n";
        std::cout << "Opcode (Operation)\tLevel Difference (L)\tAddress/Value (A)\n";
        for (const auto& pcode : allPcode) {
            std::cout << static_cast<int>(pcode->getF()) << " (" << getOperatorString(pcode->getF()) << ")\t\t\t" << pcode->getL() << "\t\t\t" << pcode->getA() << "\n";
        }
        std::cout << std::endl;
    }

    std::string getOperatorString(Operator op) const {
        switch (op) {
        case Operator::LIT: return "LIT";
        case Operator::OPR: return "OPR";
        case Operator::LOD: return "LOD";
        case Operator::STO: return "STO";
        case Operator::CAL: return "CAL";
        case Operator::INT: return "INT";
        case Operator::JMP: return "JMP";
        case Operator::JPC: return "JPC";
        default: return "UNKNOWN";
        }
    }
};

#endif // PL0COMPILER_H
