#ifndef PL0PCODEMANAGER_H
#define PL0PCODEMANAGER_H

#include <vector>
#include <memory>
#include "PL0Pcode.h"

class PL0PcodeManager {
private:
    std::vector<std::shared_ptr<PL0Pcode>> allPcode;

public:
    PL0PcodeManager() = default;

    std::vector<std::shared_ptr<PL0Pcode>> getAllPcode() const {
        return allPcode;
    }

    int getPcodePtr() const {
        return allPcode.size();
    }

    void gen(const std::shared_ptr<PL0Pcode>& pcode) {
        allPcode.push_back(pcode);
    }

    void gen(Operator L, int F, int A) {
        allPcode.push_back(std::make_shared<PL0Pcode>(L, F, A));
    }
};

#endif // PL0PCODEMANAGER_H
#pragma once
