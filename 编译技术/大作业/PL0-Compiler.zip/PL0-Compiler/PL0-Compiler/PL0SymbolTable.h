#ifndef PL0SYMBOLTABLE_H
#define PL0SYMBOLTABLE_H

#include <vector>
#include <memory>
#include <string>
#include "PL0Symbol.h"

class PL0SymbolTable {
private:
    std::vector<std::shared_ptr<PL0Symbol>> allSymbol;

    const int con = 1; // ����������1��ʾ
    const int var = 2; // ����������2��ʾ
    const int proc = 3; // ����������3��ʾ

    int ptr = 0;

public:
    PL0SymbolTable() = default;

    // ����ű��в��볣��
    void enterConst(const std::string& name, int level, int value, int address) {
        allSymbol.push_back(std::make_shared<PL0Symbol>(con, value, level, address, 0, name));
        ptr++;
    }

    // ����ű��в������
    void enterVar(const std::string& name, int level, int address) {
        allSymbol.push_back(std::make_shared<PL0Symbol>(var, level, address, 0, name));
        ptr++;
    }

    // ����ű��в������
    void enterProc(const std::string& name, int level, int address) {
        allSymbol.push_back(std::make_shared<PL0Symbol>(proc, level, address, 0, name));
        ptr++;
    }

    // �ڷ��ű���ǰ����ұ����Ƿ����
    bool isNowExists(const std::string& name, int level) const {
        for (const auto& symbol : allSymbol) {
            if (symbol->getName() == name && symbol->getLevel() == level) {
                return true;
            }
        }
        return false;
    }

    // �ڷ��ű�֮ǰ����ҷ����Ƿ����
    bool isPreExists(const std::string& name, int level) const {
        for (const auto& symbol : allSymbol) {
            if (symbol->getName() == name && symbol->getLevel() <= level) {
                return true;
            }
        }
        return false;
    }

    // �����Ʋ��ұ���
    std::shared_ptr<PL0Symbol> getSymbol(const std::string& name) const {
        for (auto it = allSymbol.rbegin(); it != allSymbol.rend(); ++it) {
            if ((*it)->getName() == name) {
                return *it;
            }
        }
        return nullptr;
    }

    // ���ҵ�ǰ�����ڵĹ���
    int getLevelProc(int level) const {
        for (int i = allSymbol.size() - 1; i >= 0; --i) {
            if (allSymbol[i]->getType() == proc) {
                return i;
            }
        }
        return -1;
    }

    std::vector<std::shared_ptr<PL0Symbol>> getAllSymbol() const {
        return allSymbol;
    }

    void setPtr(int _ptr) {
        ptr = _ptr;
    }

    int getPtr() const {
        return ptr;
    }

    int getLength() const {
        return allSymbol.size();
    }

    int getCon() const {
        return con;
    }

    int getVar() const {
        return var;
    }

    int getProc() const {
        return proc;
    }
};

#endif // PL0SYMBOLTABLE_H
#pragma once
