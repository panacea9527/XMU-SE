#include <iostream>
#include "PL0Compiler.h"

int main() {
    // ָ��Դ�ļ�·��
    std::string filename = "test3.txt";

    PL0Compiler compiler;
    compiler.compile(filename);

    return 0;
}
