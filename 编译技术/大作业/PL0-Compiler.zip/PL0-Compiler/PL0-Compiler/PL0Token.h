#ifndef PL0TOKEN_H
#define PL0TOKEN_H

#include <string>

// ö������SymType
enum class PL0SymType {
    BEG, END, IF, THEN, ELS, CON, PROC, VAR, DO, WHI, CAL, REA, WRI, ODD, REP, UNT,
    EQU, LES, LESE, LARE, LAR, NEQE, ADD, SUB, MUL, DIV,
    SYM, CONST,
    CEQU, COMMA, SEMIC, POI, LBR, RBR,
    COL,
    END_OF_FILE // �޸ĺ��EOF
};

class PL0Token {
private:
    PL0SymType st; // token�����
    int line; // token�����У�������ʹ��
    std::string value; // token��ֵ��ֻ�б�ʶ���ͳ�����ֵ

public:
    // ���캯��
    PL0Token(PL0SymType _st, int _line, const std::string& _value)
        : st(_st), line(_line), value(_value) {}

    // getter��setter
    void setSt(PL0SymType _st) {
        st = _st;
    }

    void setLine(int _line) {
        line = _line;
    }

    void setValue(const std::string& _value) {
        value = _value;
    }

    // ��ȡ����
    PL0SymType getSt() const {
        return st;
    }

    int getLine() const {
        return line;
    }

    std::string getValue() const {
        return value;
    }
};

#endif // PL0TOKEN_H
