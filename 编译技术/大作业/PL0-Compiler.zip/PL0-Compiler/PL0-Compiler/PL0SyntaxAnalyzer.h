#ifndef PL0SYNTAXANALYZER_H
#define PL0SYNTAXANALYZER_H

#include <vector>
#include <string>
#include <memory>
#include <iostream>
#include <fstream>
#include "PL0LexAnalysis.h"
#include "PL0Token.h"
#include "PL0PcodeManager.h"
#include "PL0SymbolTable.h"
#include "PL0Interpreter.h"

class PL0SyntaxAnalyzer {
private:
    std::shared_ptr<PL0LexAnalysis> lex;
    std::vector<std::shared_ptr<PL0Token>> allToken; // ����ʷ��������
    std::shared_ptr<PL0PcodeManager> pcodeManager; // �������ɵ�Pcode
    std::shared_ptr<PL0SymbolTable> symbolTable; // ���ű�����
    std::vector<std::string> errorMessage; // ���������Ϣ

    bool errorHappen = false; // ��¼����������Ƿ�������
    int tokenPtr = 0; // ָ��ǰtoken��ָ��

    int level = 0;
    int address = 0;
    const int addIncrement = 1;

public:
    PL0SyntaxAnalyzer(const std::string& filename) {
        lex = std::make_shared<PL0LexAnalysis>(filename);
        allToken = lex->getAllToken();

        pcodeManager = std::make_shared<PL0PcodeManager>();

        symbolTable = std::make_shared<PL0SymbolTable>();

        errorMessage = std::vector<std::string>();
    }

    bool compile() {
        program();
        return (!errorHappen);
    }

private:
    void program() {
        block();
        if (allToken[tokenPtr]->getSt() == PL0SymType::POI) {
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() != PL0SymType::END_OF_FILE) {
                errorHandle(18, "");
            }
        }
        else {
            errorHandle(17, "");
        }
    }

    void block() {
        int address_cp = address;
        int start = symbolTable->getPtr();
        int pos = 0;
        address = 3;
        if (start > 0) {
            pos = symbolTable->getLevelProc(level);
        }

        int tmpPcodePtr = pcodeManager->getPcodePtr();
        pcodeManager->gen(Operator::JMP, 0, 0);

        if (allToken[tokenPtr]->getSt() == PL0SymType::CON) {
            conDeclare();
        }
        if (allToken[tokenPtr]->getSt() == PL0SymType::VAR) {
            varDeclare();
        }
        if (allToken[tokenPtr]->getSt() == PL0SymType::PROC) {
            proc();
        }

        pcodeManager->getAllPcode()[tmpPcodePtr]->setA(pcodeManager->getPcodePtr());
        pcodeManager->gen(Operator::INT, 0, address);
        if (start != 0) {
            symbolTable->getAllSymbol()[pos]->setValue(pcodeManager->getPcodePtr() - 1 - symbolTable->getAllSymbol()[pos]->getSize());
        }

        statement();
        pcodeManager->gen(Operator::OPR, 0, 0);

        address = address_cp;
    }

    void conDeclare() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::CON) {
            tokenPtr++;
            conHandle();
            while (allToken[tokenPtr]->getSt() == PL0SymType::COMMA || allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                if (allToken[tokenPtr]->getSt() == PL0SymType::COMMA) {
                    tokenPtr++;
                }
                else {
                    errorHandle(23, "");
                }
                conHandle();
            }
            if (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC) {
                tokenPtr++;
            }
            else {
                errorHandle(0, "");
            }
        }
        else {
            errorHandle(-1, "");
        }
    }

    void conHandle() {
        std::string name;
        int value;
        if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
            name = allToken[tokenPtr]->getValue();
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() == PL0SymType::EQU || allToken[tokenPtr]->getSt() == PL0SymType::CEQU) {
                if (allToken[tokenPtr]->getSt() == PL0SymType::CEQU) {
                    errorHandle(3, "");
                }
                tokenPtr++;
                if (allToken[tokenPtr]->getSt() == PL0SymType::CONST) {
                    value = std::stoi(allToken[tokenPtr]->getValue());
                    if (symbolTable->isNowExists(name, level)) {
                        errorHandle(15, name);
                    }
                    symbolTable->enterConst(name, level, value, address);
                    tokenPtr++;
                }
            }
            else {
                errorHandle(3, "");
            }
        }
        else {
            errorHandle(1, "");
        }
    }

    void varDeclare() {
        std::string name;
        if (allToken[tokenPtr]->getSt() == PL0SymType::VAR) {
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                name = allToken[tokenPtr]->getValue();
                if (symbolTable->isNowExists(name, address)) {
                    errorHandle(15, name);
                }
                symbolTable->enterVar(name, level, address);
                address += addIncrement;
                tokenPtr++;
                while (allToken[tokenPtr]->getSt() == PL0SymType::COMMA || allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                    if (allToken[tokenPtr]->getSt() == PL0SymType::COMMA) {
                        tokenPtr++;
                    }
                    else {
                        errorHandle(23, "");
                    }
                    if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                        name = allToken[tokenPtr]->getValue();
                        if (symbolTable->isNowExists(name, address)) {
                            errorHandle(15, name);
                        }
                        symbolTable->enterVar(name, level, address);
                        address += addIncrement;
                        tokenPtr++;
                    }
                    else {
                        errorHandle(1, "");
                        return;
                    }
                }
                if (allToken[tokenPtr]->getSt() != PL0SymType::SEMIC) {
                    errorHandle(0, "");
                    return;
                }
                else {
                    tokenPtr++;
                }
            }
            else {
                errorHandle(1, "");
                return;
            }
        }
        else {
            errorHandle(-1, "");
            return;
        }
    }

    void proc() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::PROC) {
            tokenPtr++;
            int pos;
            if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                std::string name = allToken[tokenPtr]->getValue();
                if (symbolTable->isNowExists(name, level)) {
                    errorHandle(15, name);
                }
                pos = symbolTable->getPtr();
                symbolTable->enterProc(name, level, address);
                address += addIncrement;
                level++;
                tokenPtr++;
                if (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC) {
                    tokenPtr++;
                }
                else {
                    errorHandle(0, "");
                }
                block();
                while (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC || allToken[tokenPtr]->getSt() == PL0SymType::PROC) {
                    if (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC) {
                        tokenPtr++;
                    }
                    else {
                        errorHandle(0, "");
                    }
                    level--;
                    proc();
                }
            }
            else {
                errorHandle(-1, "");
                return;
            }
        }
    }

    void body() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::BEG) {
            tokenPtr++;
            statement();
            while (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC || isHeadOfStatement()) {
                if (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC) {
                    tokenPtr++;
                }
                else {
                    if (allToken[tokenPtr]->getSt() != PL0SymType::END) {
                        errorHandle(0, "");
                    }
                }
                if (allToken[tokenPtr]->getSt() == PL0SymType::END) {
                    errorHandle(21, "");
                    break;
                }
                statement();
            }
            if (allToken[tokenPtr]->getSt() == PL0SymType::END) {
                tokenPtr++;
            }
            else {
                errorHandle(7, "");
                return;
            }
        }
        else {
            errorHandle(6, "");
            return;
        }
    }

    void statement() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::IF) {
            tokenPtr++;
            condition();
            if (allToken[tokenPtr]->getSt() == PL0SymType::THEN) {
                int pos1 = pcodeManager->getPcodePtr();
                pcodeManager->gen(Operator::JPC, 0, 0);
                tokenPtr++;
                statement();
                int pos2 = pcodeManager->getPcodePtr();
                pcodeManager->gen(Operator::JMP, 0, 0);
                pcodeManager->getAllPcode()[pos1]->setA(pcodeManager->getPcodePtr());
                pcodeManager->getAllPcode()[pos2]->setA(pcodeManager->getPcodePtr());
                if (allToken[tokenPtr]->getSt() == PL0SymType::ELS) {
                    tokenPtr++;
                    statement();
                    pcodeManager->getAllPcode()[pos2]->setA(pcodeManager->getPcodePtr());
                }
            }
            else {
                errorHandle(8, "");
                return;
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::WHI) {
            int pos1 = pcodeManager->getPcodePtr();
            tokenPtr++;
            condition();
            if (allToken[tokenPtr]->getSt() == PL0SymType::DO) {
                int pos2 = pcodeManager->getPcodePtr();
                pcodeManager->gen(Operator::JPC, 0, 0);
                tokenPtr++;
                statement();
                pcodeManager->gen(Operator::JMP, 0, pos1);
                pcodeManager->getAllPcode()[pos2]->setA(pcodeManager->getPcodePtr());
            }
            else {
                errorHandle(9, "");
                return;
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::CAL) {
            tokenPtr++;
            std::shared_ptr<PL0Symbol> tmp;
            if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                std::string name = allToken[tokenPtr]->getValue();
                if (symbolTable->isPreExists(name, level)) {
                    tmp = symbolTable->getSymbol(name);
                    if (tmp->getType() == symbolTable->getProc()) {
                        pcodeManager->gen(Operator::CAL, level - tmp->getLevel(), tmp->getValue());
                    }
                    else {
                        errorHandle(11, "");
                        return;
                    }
                }
                else {
                    errorHandle(10, "");
                    return;
                }
                tokenPtr++;
            }
            else {
                errorHandle(1, "");
                return;
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::REA) {
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() == PL0SymType::LBR) {
                tokenPtr++;
                if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                    std::string name = allToken[tokenPtr]->getValue();
                    if (!symbolTable->isPreExists(name, level)) {
                        errorHandle(10, "");
                        return;
                    }
                    else {
                        std::shared_ptr<PL0Symbol> tmp = symbolTable->getSymbol(name);
                        if (tmp->getType() == symbolTable->getVar()) {
                            pcodeManager->gen(Operator::OPR, 0, 16);
                            pcodeManager->gen(Operator::STO, level - tmp->getLevel(), tmp->getAddress());
                        }
                        else {
                            errorHandle(12, "");
                            return;
                        }
                    }
                }
                tokenPtr++;
                while (allToken[tokenPtr]->getSt() == PL0SymType::COMMA) {
                    tokenPtr++;
                    if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                        std::string name = allToken[tokenPtr]->getValue();
                        if (!symbolTable->isPreExists(name, level)) {
                            errorHandle(10, "");
                            return;
                        }
                        else {
                            std::shared_ptr<PL0Symbol> tmp = symbolTable->getSymbol(name);
                            if (tmp->getType() == symbolTable->getVar()) {
                                pcodeManager->gen(Operator::OPR, 0, 16);
                                pcodeManager->gen(Operator::STO, level - tmp->getLevel(), tmp->getAddress());
                            }
                            else {
                                errorHandle(12, "");
                                return;
                            }
                        }
                        tokenPtr++;
                    }
                    else {
                        errorHandle(1, "");
                        return;
                    }
                }
                if (allToken[tokenPtr]->getSt() == PL0SymType::RBR) {
                    tokenPtr++;
                }
                else {
                    errorHandle(5, "");
                    return;
                }
            }
            else {
                errorHandle(4, "");
                return;
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::WRI) {
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() == PL0SymType::LBR) {
                tokenPtr++;
                expression();
                pcodeManager->gen(Operator::OPR, 0, 14);
                while (allToken[tokenPtr]->getSt() == PL0SymType::COMMA) {
                    tokenPtr++;
                    expression();
                    pcodeManager->gen(Operator::OPR, 0, 14);
                }
                pcodeManager->gen(Operator::OPR, 0, 15);
                if (allToken[tokenPtr]->getSt() == PL0SymType::RBR) {
                    tokenPtr++;
                }
                else {
                    errorHandle(5, "");
                    return;
                }
            }
            else {
                errorHandle(4, "");
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::BEG) {
            body();
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
            std::string name = allToken[tokenPtr]->getValue();
            tokenPtr++;
            if (allToken[tokenPtr]->getSt() == PL0SymType::CEQU || allToken[tokenPtr]->getSt() == PL0SymType::EQU || allToken[tokenPtr]->getSt() == PL0SymType::COL) {
                if (allToken[tokenPtr]->getSt() == PL0SymType::EQU || allToken[tokenPtr]->getSt() == PL0SymType::COL) {
                    errorHandle(3, "");
                }
                tokenPtr++;
                expression();
                if (!symbolTable->isPreExists(name, level)) {
                    errorHandle(14, name);
                    return;
                }
                else {
                    std::shared_ptr<PL0Symbol> tmp = symbolTable->getSymbol(name);
                    if (tmp->getType() == symbolTable->getVar()) {
                        pcodeManager->gen(Operator::STO, level - tmp->getLevel(), tmp->getAddress());
                    }
                    else {
                        errorHandle(13, name);
                        return;
                    }
                }
            }
            else {
                errorHandle(3, "");
                return;
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::REP) {
            tokenPtr++;
            int pos = pcodeManager->getPcodePtr();
            statement();
            while (allToken[tokenPtr]->getSt() == PL0SymType::SEMIC || isHeadOfStatement()) {
                if (isHeadOfStatement()) {
                    errorHandle(1, "");
                }
                else {
                    tokenPtr++;
                }
                if (allToken[tokenPtr]->getSt() == PL0SymType::UNT) {
                    errorHandle(22, "");
                    break;
                }
                tokenPtr++;
                statement();
            }
            if (allToken[tokenPtr]->getSt() == PL0SymType::UNT) {
                tokenPtr++;
                condition();
                pcodeManager->gen(Operator::JPC, 0, pos);
            }
            else {
                errorHandle(19, "");
                return;
            }
        }
        else {
            errorHandle(1, "");
            return;
        }
    }

    void condition() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::ODD) {
            pcodeManager->gen(Operator::OPR, 0, 6);
            tokenPtr++;
            expression();
        }
        else {
            expression();
            PL0SymType tmp = allToken[tokenPtr]->getSt();
            tokenPtr++;
            expression();
            if (tmp == PL0SymType::EQU) {
                pcodeManager->gen(Operator::OPR, 0, 8);
            }
            else if (tmp == PL0SymType::NEQE) {
                pcodeManager->gen(Operator::OPR, 0, 9);
            }
            else if (tmp == PL0SymType::LES) {
                pcodeManager->gen(Operator::OPR, 0, 10);
            }
            else if (tmp == PL0SymType::LARE) {
                pcodeManager->gen(Operator::OPR, 0, 11);
            }
            else if (tmp == PL0SymType::LAR) {
                pcodeManager->gen(Operator::OPR, 0, 12);
            }
            else if (tmp == PL0SymType::LESE) {
                pcodeManager->gen(Operator::OPR, 0, 13);
            }
            else {
                errorHandle(2, "");
            }
        }
    }

    void expression() {
        PL0SymType tmp = allToken[tokenPtr]->getSt();
        if (tmp == PL0SymType::ADD || tmp == PL0SymType::SUB) {
            tokenPtr++;
        }
        term();
        if (tmp == PL0SymType::SUB) {
            pcodeManager->gen(Operator::OPR, 0, 1);
        }
        while (allToken[tokenPtr]->getSt() == PL0SymType::ADD || allToken[tokenPtr]->getSt() == PL0SymType::SUB) {
            tmp = allToken[tokenPtr]->getSt();
            tokenPtr++;
            term();
            if (tmp == PL0SymType::ADD) {
                pcodeManager->gen(Operator::OPR, 0, 2);
            }
            else if (tmp == PL0SymType::SUB) {
                pcodeManager->gen(Operator::OPR, 0, 3);
            }
        }
    }

    void term() {
        factor();
        while (allToken[tokenPtr]->getSt() == PL0SymType::MUL || allToken[tokenPtr]->getSt() == PL0SymType::DIV) {
            PL0SymType tmp = allToken[tokenPtr]->getSt();
            tokenPtr++;
            factor();
            if (tmp == PL0SymType::MUL) {
                pcodeManager->gen(Operator::OPR, 0, 4);
            }
            else if (tmp == PL0SymType::DIV) {
                pcodeManager->gen(Operator::OPR, 0, 5);
            }
        }
    }

    void factor() {
        if (allToken[tokenPtr]->getSt() == PL0SymType::CONST) {
            pcodeManager->gen(Operator::LIT, 0, std::stoi(allToken[tokenPtr]->getValue()));
            tokenPtr++;
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::LBR) {
            tokenPtr++;
            expression();
            if (allToken[tokenPtr]->getSt() == PL0SymType::RBR) {
                tokenPtr++;
            }
            else {
                errorHandle(5, "");
            }
        }
        else if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
            std::string name = allToken[tokenPtr]->getValue();
            if (!symbolTable->isPreExists(name, level)) {
                errorHandle(10, "");
                return;
            }
            else {
                std::shared_ptr<PL0Symbol> tmp = symbolTable->getSymbol(name);
                if (tmp->getType() == symbolTable->getVar()) {
                    pcodeManager->gen(Operator::LOD, level - tmp->getLevel(), tmp->getAddress());
                }
                else if (tmp->getType() == symbolTable->getCon()) {
                    pcodeManager->gen(Operator::LIT, 0, tmp->getValue());
                }
                else {
                    errorHandle(12, "");
                    return;
                }
            }
            tokenPtr++;
        }
        else {
            errorHandle(1, "");
            return;
        }
    }

    bool isHeadOfStatement() {
        return (allToken[tokenPtr]->getSt() == PL0SymType::IF ||
            allToken[tokenPtr]->getSt() == PL0SymType::WHI ||
            allToken[tokenPtr]->getSt() == PL0SymType::CAL ||
            allToken[tokenPtr]->getSt() == PL0SymType::REA ||
            allToken[tokenPtr]->getSt() == PL0SymType::WRI ||
            allToken[tokenPtr]->getSt() == PL0SymType::BEG ||
            allToken[tokenPtr]->getSt() == PL0SymType::SYM ||
            allToken[tokenPtr]->getSt() == PL0SymType::REP);
    }

    void errorHandle(int k, const std::string& name) {
        errorHappen = true;
        std::string error;
        switch (k) {
        case -1:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": wrong token";
            break;
        case 0:
            if (allToken[tokenPtr]->getSt() == PL0SymType::SYM) {
                error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing ; before " + allToken[tokenPtr]->getValue();
            }
            else {
                error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing ; before " + std::to_string(static_cast<int>(allToken[tokenPtr]->getSt()));
            }
            break;
        case 1:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Identifier illegal";
            break;
        case 2:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": illegal compare symbol";
            break;
        case 3:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Const assign must be =";
            break;
        case 4:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing (";
            break;
        case 5:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missind )";
            break;
        case 6:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing begin";
            break;
        case 7:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing end";
            break;
        case 8:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing then";
            break;
        case 9:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing do";
            break;
        case 10:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Not exist " + allToken[tokenPtr]->getValue();
            break;
        case 11:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": " + allToken[tokenPtr]->getValue() + " is not a procedure";
            break;
        case 12:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": " + allToken[tokenPtr]->getValue() + " is not a variable";
            break;
        case 13:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": " + name + " is not a varible";
            break;
        case 14:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": not exist " + name;
            break;
        case 15:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Already exist " + name;
            break;
        case 16:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Number of parameters of procedure " + name + " is incorrect";
            break;
        case 17:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing .";
            break;
        case 18:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": too much code after .";
            break;
        case 19:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing until";
            break;
        case 20:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Assign must be :=";
            break;
        case 21:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": ; is no need before end";
            break;
        case 22:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": ; is no need before until";
            break;
        case 23:
            error = "Error happened in line " + std::to_string(allToken[tokenPtr]->getLine()) + ": Missing ,";
            break;
        }
        errorMessage.push_back(error);
    }

public:
    std::vector<std::string> getErrorMessage() const {
        return errorMessage;
    }

    void showAllToken() const {
        for (const auto& token : allToken) {
            std::cout << static_cast<int>(token->getSt()) << " " << token->getLine() << " " << token->getValue() << std::endl;
        }
    }

    std::vector<std::shared_ptr<PL0Token>> getAllToken() const {
        return allToken;
    }

    void getAllSymbol() const {
        std::vector<std::shared_ptr<PL0Symbol>> display = symbolTable->getAllSymbol();
        for (const auto& symbol : display) {
            std::cout << symbol->getType() << " " << symbol->getName() << " " << symbol->getValue() << " " << symbol->getLevel() << " " << symbol->getAddress() << std::endl;
        }
    }

    std::vector<std::shared_ptr<PL0Symbol>> getPL0SymbolTable() const {
        return symbolTable->getAllSymbol();
    }

    void showAllPcode() const {
        std::vector<std::shared_ptr<PL0Pcode>> display = pcodeManager->getAllPcode();
        for (size_t i = 0; i < display.size(); ++i) {
            std::cout << i << " " << static_cast<int>(display[i]->getF()) << "     ";
            std::cout << " " << display[i]->getL() << " " << display[i]->getA() << std::endl;
        }
    }

    std::vector<std::shared_ptr<PL0Pcode>> getAllPcode() const {
        return pcodeManager->getAllPcode();
    }

    std::vector<std::string> interpreter(const std::vector<int>& input) {
        PL0Interpreter one(input);
        one.setAllPcode(pcodeManager);
        one.interpreter();
        return one.getOutput();
    }

    void interpreter() {
        PL0Interpreter one;
        one.setAllPcode(pcodeManager);
        one.interpreter();
    }
};

#endif // PL0SYNTAXANALYZER_H
#pragma once
