#define _CRT_SECURE_NO_DEPRECATE
#pragma comment(lib,"Ws2_32.lib" )
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctime>
#include<winsock.h>
#include <fcntl.h>
#define SIZE 1024

void send_file_data(FILE* fp, int sockfd, struct sockaddr_in addr) {
    int n;
    int count = 0;
    bool server_alive = true;
    char buffer[SIZE];

    // ���׽�������Ϊ������ģʽ
    u_long mode = 1;
    ioctlsocket(sockfd, FIONBIO, &mode);

    while (fgets(buffer, SIZE, fp) != NULL && server_alive) {
        printf("��������: %s", buffer);

        n = sendto(sockfd, buffer, SIZE, 0, (struct sockaddr*)&addr, sizeof(addr));
        if (n == -1) {
            perror("[ERROR] sending data to the server.");
            exit(1);
        }
        ZeroMemory(buffer, SIZE);

        count++;

        // ÿ����2�����ݾͼ��һ�η�����Ƿ񻹴��
        if (count % 2 == 0) {
            fd_set fds;
            timeval tv;
            int len = sizeof(addr);
            char recv_buffer[SIZE];
            int retval;

            FD_ZERO(&fds);
            FD_SET(sockfd, &fds);

            tv.tv_sec = 0;
            tv.tv_usec = 1000000; // ���ó�ʱʱ��

            retval = select(0, &fds, NULL, NULL, &tv);
            if (retval == 0) {
                ;
            }
            else if (retval < 0) {
                perror("[ERROR] select error");
                exit(1);
            }
            else {
                retval = recvfrom(sockfd, recv_buffer, SIZE, 0, (struct sockaddr*)&addr, &len);
                if (retval == -1) {
                    printf("�������Ͽ����ӡ���");
                    exit(1);
                }
                server_alive = true;
            }
        }
    }
    strcpy(buffer, "END");
    sendto(sockfd, buffer, SIZE, 0, (struct sockaddr*)&addr, sizeof(addr));
    fclose(fp);
}



void start()
{
    WORD version(0);
    WSADATA wsadata;
    int socket_return(0);
    version = MAKEWORD(2, 0);
    socket_return = WSAStartup(version, &wsadata);
    if (socket_return != 0)
    {
        exit(0);
    }
}

int main(void)
{
    start();
    char ip[] = "127.0.0.1";
    const int port = 8848;

    int server_sockfd;
    struct sockaddr_in server_addr;
    char filename[] = "send.txt";
    FILE* fp = fopen(filename, "r");

    server_sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_sockfd < 0)
    {
        perror("socket����");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = port;
    server_addr.sin_addr.s_addr = inet_addr(ip);


    if (fp == NULL)
    {
        perror("��ȡ�ļ�����");
        exit(1);
    }

    send_file_data(fp, server_sockfd, server_addr);

    printf("\n���ݴ�����ɣ�\n");
    printf("���ڹر����ӡ���\n");

    closesocket(server_sockfd);

    return 0;
}
