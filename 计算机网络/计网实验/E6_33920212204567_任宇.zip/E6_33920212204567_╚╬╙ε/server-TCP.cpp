#define  _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <stdio.h>
#include <stdio.h>
#include <winsock2.h>
#include "FileHelper.h"
#include<iostream>
#pragma comment(lib,"ws2_32.lib")
#define SIZE 1024
using namespace std;

int main(int argc, char* argv[])
{
	WORD version(0);
	WSADATA wsadata;
	int socket_return(0);
	version = MAKEWORD(2, 0);
	socket_return = WSAStartup(version, &wsadata);
	if (socket_return != 0)
	{
		exit(0);
	}

	char ip[] = "127.0.0.1";
	int port = 8888;
	int e;
	int slisten, new_sock;
	struct sockaddr_in server_addr, new_addr;
	int addr_size;
	char buffer[SIZE];
	slisten = socket(AF_INET, SOCK_STREAM, 0);

	if (slisten < 0)
	{
		perror("socket��������ʧ��");
		exit(1);
	}
	printf("������socket�����ɹ�\n");

	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr(ip);
	server_addr.sin_port = htons(8888);
	e = bind(slisten, (struct sockaddr*)&server_addr, sizeof(server_addr));
	if (e < 0) {
		perror("bind��������ʧ��");
		exit(1);
	}
	printf("bind�������óɹ�\n");

	if (listen(slisten, 10) == 0) {
		printf("listen�������óɹ�����ʼ����\n");
	}
	else {
		perror("listen��������ʧ��");
		exit(1);
	}
	FileHelper fh;
	SOCKET sClient;
	sockaddr_in remoteAddr;
	int nAddrlen = sizeof(remoteAddr);
	char revData[BUFSIZ];
	while (true)
	{
		printf("�ȴ�����...\n");
		sClient = accept(slisten, (SOCKADDR*)&remoteAddr, &nAddrlen);
		//cout << sClient<<;
		if (sClient == INVALID_SOCKET)
		{
			printf("accept error !");
			continue;
		}
		printf("���յ�һ�����ӣ�%s \r\n", inet_ntoa(remoteAddr.sin_addr));

		int ret = 0;
		long long count = 0;
		char sendData[BUFSIZ] = "�����У�";
		ret = recv(sClient, revData, BUFSIZ, 0);
		char fromname[BUFSIZ] = {};
		strcpy(fromname, revData);
		char finame[MAX_PATH] = { "" };
		char over[BUFSIZ] = "Finnal";

		strcat(finame, revData);
		printf(finame);
		FILE* f = fopen(finame, "wb");
		if (f == NULL)printf("�ļ�����ʧ��");
		send(sClient, sendData, BUFSIZ, 0);
		while ((ret = recv(sClient, revData, BUFSIZ, 0)) > 0)
		{
			printf("%db\n", count += ret);
			if (strcmp(revData, over) == 0)
			{
				printf("�ļ�%s����ɹ�\n", fromname);
				break;
				send(sClient, over, BUFSIZ, 0);
			}
			fwrite(revData, 1, ret, f);
			send(sClient, sendData, BUFSIZ, 0);
		}
		fclose(f);
		if (strcmp(revData, over) != 0)
		{
			printf("IP��%s������%s���������ʧȥ����\n", inet_ntoa(remoteAddr.sin_addr), fromname);
			remove(finame);
		}
		closesocket(sClient);
	}

	closesocket(slisten);
	WSACleanup();
	return 0;
}