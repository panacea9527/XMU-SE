#define _CRT_SECURE_NO_DEPRECATE
#pragma comment(lib,"Ws2_32.lib" )
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock.h>

#define SIZE 1024


void write_file(int sockfd, struct sockaddr_in addr)
{
    char filename[] = "recv.txt";
    int n;
    char buffer[SIZE];
    int addr_size;
    FILE* fp = fp = fopen(filename, "w");

    struct timeval timeout;
    timeout.tv_sec = 5000;
    timeout.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));

    while (1)
    {
        addr_size = sizeof(addr);
        n = recvfrom(sockfd, buffer, SIZE, 0, (struct sockaddr*)&addr, &addr_size);
        if (n == -1)
        {
            printf("��ʱ���Ͽ����ӣ��رշ����\n");
            exit(-1);
        }
        if (strcmp(buffer, "END") == 0)
            break;
        printf("���յ�������: %s", buffer);
        fprintf(fp, "%s", buffer);
        ZeroMemory(buffer, SIZE);
    }
    fclose(fp);
}


void start()
{
    WORD version(0);
    WSADATA wsadata;
    int socket_return(0);
    version = MAKEWORD(2, 0);
    socket_return = WSAStartup(version, &wsadata);
    if (socket_return != 0)
        exit(0);

}

int main()
{
    start();
    char ip[] = "127.0.0.1";
    const int port = 8848;

    int server_sockfd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[SIZE];
    int e;

    server_sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_sockfd < 0)
    {
        perror("socket error");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = port;
    server_addr.sin_addr.s_addr = inet_addr(ip);

    e = bind(server_sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if (e < 0)
    {
        perror("bind error");
        exit(1);
    }

    printf(" UDP�ļ���������������\n");
    write_file(server_sockfd, server_addr);
    printf("���ݴ�����ɣ�\n");
    printf("�رշ���ˡ���\n");

    closesocket(server_sockfd);

    return 0;
}
