/********************************
 * 
 * Notes:  lab   
 * 接收脚本 
 *******************************/
(
    function main() {

       //获取当前时间，并转为要求的格式
       nowTime = new Date();    //创建实例
	year = nowTime.getFullYear();    //年份
       //月份，小于10前面补0，下面同理
       month = nowTime.getMonth() + 1 >= 10 ? nowTime.getMonth() + 1 : '0' + (nowTime.getMonth() + 1); 
	day = nowTime.getDate() >= 10 ? nowTime.getDate() : '0' + nowTime.getDate();
	hours = nowTime.getHours() >= 10 ? nowTime.getHours() : '0' + nowTime.getHours();
	minute = nowTime.getMinutes() >= 10 ? nowTime.getMinutes() : '0' + nowTime.getMinutes();
	second = nowTime.getSeconds() >= 10 ? nowTime.getSeconds() : '0' + nowTime.getSeconds();
       //获取收到的数据
       var str=receive.get();
       //输出到窗口
       receive.write("[RECV "+year + '-' + month + '-' + day + " " + hours + ":" + minute + ":" + second+"]"+str);
        return ;
    }
)()