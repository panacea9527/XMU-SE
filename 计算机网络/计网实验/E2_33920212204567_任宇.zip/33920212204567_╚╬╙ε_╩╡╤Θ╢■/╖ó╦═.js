/********************************
 * Notes:  test   
 * 发送脚本
 *******************************/

(
    function main() {
       //获取发送的数据
       var str = send.get();

       //获取当前时间 
       nowTime = new Date(),
	year = nowTime.getFullYear(),
       month = nowTime.getMonth() + 1 >= 10 ? nowTime.getMonth() + 1 : '0' + (nowTime.getMonth() + 1),
	day = nowTime.getDate() >= 10 ? nowTime.getDate() : '0' + nowTime.getDate(),
	hours = nowTime.getHours() >= 10 ? nowTime.getHours() : '0' + nowTime.getHours(),
	minute = nowTime.getMinutes() >= 10 ? nowTime.getMinutes() : '0' + nowTime.getMinutes(),
	second = nowTime.getSeconds() >= 10 ? nowTime.getSeconds() : '0' + nowTime.getSeconds(),
       str = "[SENT "+year + '-' + month + '-' + day + " " + hours + ":" + minute + ":" + second+"]"+str;
       send.writeToReceice(str);

       //string转Uint8Array
        var arr = [];
        for (var i = 0, j = str.length; i < j; ++i) {
               arr.push(str.charCodeAt(i));
         }
        var senddata = new Uint8Array(arr);
  
        return senddata;
    }
)()