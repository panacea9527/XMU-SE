#define WIN32
#include<iostream>
#include<sstream>
#include<string>
#include<map>
#include<fstream>
#include <pcap.h>
#pragma warning(disable:4996)
using namespace std;
map<string, string[3]> ftp;
bool flag;
typedef struct mac_header
{
	u_char dest_addr[6];
	u_char src_addr[6];
	u_char type[2];
} mac_header;

/* IPv4 �ײ� ,20�ֽ�*/
typedef struct ip_header {
	u_char  ver_ihl;        // �汾 (4 bits) + �ײ����� (4 bits)  
	u_char  tos;            // ��������(Type of service)  
	u_short tlen;           // �ܳ�(Total length)  
	u_short identification; // ��ʶ(Identification)  
	u_short flags_fo;       // ��־λ(Flags) (3 bits) + ��ƫ����(Fragment offset) (13 bits)  
	u_char  ttl;            // ���ʱ��(Time to live)  
	u_char  proto;          // Э��(Protocol)  
	u_short crc;            // �ײ�У���(Header checksum)  
	u_char  saddr[4];      // Դ��ַ(Source address)  
	u_char  daddr[4];      // Ŀ�ĵ�ַ(Destination address)  
	u_int   op_pad;         // ѡ�������(Option + Padding)  
}ip_header;
//TCPͷ�����ܳ���20�ֽ�  
typedef struct tcp_header
{
	u_short sport;            //Դ�˿ں�  
	u_short dport;             //Ŀ�Ķ˿ں�  
	u_int th_seq;                //���к�  
	u_int th_ack;               //ȷ�Ϻ�  
	u_int th1 : 4;              //tcpͷ������  
	u_int th_res : 4;             //6λ�е�4λ�ײ�����  
	u_int th_res2 : 2;            //6λ�е�2λ�ײ�����  
	u_char th_flags;            //6λ��־λ  
	u_short th_win;             //16λ���ڴ�С  
	u_short th_sum;             //16λtcp�����  
	u_short th_urp;             //16λ����ָ��  
}tcp_header;

/* �ص�����ԭ�� */
void packet_handler(u_char* param, const struct pcap_pkthdr* header, const u_char* pkt_data);
string get_request_m_ip_message(const u_char* pkt_data);
string get_response_m_ip_message(const u_char* pkt_data);
void print(const struct pcap_pkthdr* header, string m_ip_message, const u_char* pkt_data);

int main()
{
	flag = false;
	pcap_if_t* alldevs;
	pcap_if_t* d;
	int inum;
	int i = 0;
	pcap_t* adhandle;
	char errbuf[PCAP_ERRBUF_SIZE];
	u_int netmask;
	bpf_u_int32 net;
	char packet_filter[] = "tcp and (host 121.192.180.66)";
	struct bpf_program fp;
	//�ӱ��ؼ�������������豸�б�
	if (pcap_findalldevs(&alldevs, errbuf) == -1)
	{
		fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
		exit(1);
	}
	//��ӡ�豸�б�
	for (d = alldevs; d; d = d->next)
	{
		printf("%d. %s", ++i, d->name);
		if (d->description)
			printf(" (%s)\n", d->description);
		else
			printf(" (No description available)\n");
	}

	// ����豸��Ż���0�Ļ���˵��û�в��ҵ��豸
	if (i == 0)
	{
		printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
		return -1;
	}

	printf("������Ҫץ�����豸��� (1-%d):", i);
	scanf("%d", &inum);
	/* ��ת����ѡ�豸 */
	for (d = alldevs, i = 0; i < inum - 1; d = d->next, i++);
	// ������ӿ�
	adhandle = pcap_open_live(d->name, BUFSIZ, 1, 1000, errbuf);
	if (adhandle == NULL) {
		fprintf(stderr, "Couldn't open device %s: %s\n", d->name, errbuf);
		exit(EXIT_FAILURE);
	}
	// ��ȡ����ӿڵ������ַ����������
	if (pcap_lookupnet(d->description, &net, &netmask, errbuf) == -1) {
		fprintf(stderr, "Couldn't get netmask for device %s: %s\n", d->description, errbuf);
		net = 0;
		netmask = 0;
	}
	// ������˱���ʽ
	if (pcap_compile(adhandle, &fp, packet_filter, 1, netmask) == -1)
	{
		fprintf(stderr, "Couldn't parse filter %s: %s\n", packet_filter, pcap_geterr(adhandle));
		exit(EXIT_FAILURE);
	}
	// ���ù�����
	if (pcap_setfilter(adhandle, &fp) < 0)
	{
		fprintf(stderr, "Couldn't install filter %s: %s\n", packet_filter, pcap_geterr(adhandle));
		exit(EXIT_FAILURE);
	}
	printf("\n��ʼ���� %s��\n", d->description);
	pcap_freealldevs(alldevs);  //�ͷ��豸

	/* ��ʼ��׽ */
	pcap_loop(adhandle, 0, packet_handler, NULL);
	return 0;
}

static int cnt = 0;
/* �ص����������յ�ÿһ�����ݰ�ʱ�ᱻlibpcap������ */
void packet_handler(u_char* param, const struct pcap_pkthdr* header, const u_char* pkt_data)
{
	int head = 66;
	string command;
	string m_ip_message;
	for (int i = 0; i < 4; i++)
		command += (char)pkt_data[i + head];
	if (command == "USER")
	{
		m_ip_message = get_request_m_ip_message(pkt_data);
		string user;
		ostringstream sout;
		for (int i = head + 5; pkt_data[i] != 13; i++)
		{
			sout << pkt_data[i];
		}
		user = sout.str();
		ftp[m_ip_message][0] = user;
		print(header, m_ip_message, pkt_data);
	}
	else if (command == "PASS")
	{
		m_ip_message = get_request_m_ip_message(pkt_data);
		string pass;
		ostringstream sout;
		for (int i = head + 5; pkt_data[i] != 13; i++)
		{
			sout << pkt_data[i];
		}
		pass = sout.str();
		ftp[m_ip_message][1] = pass;
		print(header, m_ip_message, pkt_data);
	}
	else if (command == "230 ")
	{
		m_ip_message = get_response_m_ip_message(pkt_data);
		ftp[m_ip_message][2] = "SUCCEED";
		print(header, m_ip_message, pkt_data);
	}
	else if (command == "530 ")
	{
		m_ip_message = get_response_m_ip_message(pkt_data);
		ftp[m_ip_message][2] = "FAILD";
		print(header, m_ip_message, pkt_data);
	}
	else if (command == "QUIT")
	{
		m_ip_message = get_response_m_ip_message(pkt_data);
		ftp[m_ip_message][2] = "QUIT";
		print(header, m_ip_message, pkt_data);
	}
	else
	{
		m_ip_message = get_response_m_ip_message(pkt_data);
		print(header, m_ip_message, pkt_data);
	}
}
string get_request_m_ip_message(const u_char* pkt_data)
{
	mac_header* mh;
	ip_header* ih;
	string m_ip_message;
	string str;//empty string
	ostringstream sout;
	int length = sizeof(mac_header) + sizeof(ip_header);
	mh = (mac_header*)pkt_data;
	ih = (ip_header*)(pkt_data + sizeof(mac_header));
	for (int i = 0; i < 3; i++)
		sout << dec << (int)(ih->saddr[i]) << ".";
	sout << (int)(ih->saddr[3]) << ",";
	for (int i = 0; i < 5; i++)
		sout << hex << (int)(mh->dest_addr[i]) << "-";
	sout << (int)(mh->dest_addr[5]) << ",";
	for (int i = 0; i < 3; i++)
		sout << dec << (int)(ih->daddr[i]) << ".";
	sout << (int)(ih->daddr[3]);
	m_ip_message = sout.str();
	return m_ip_message;
}
string get_response_m_ip_message(const u_char* pkt_data)
{
	mac_header* mh;
	ip_header* ih;
	string m_ip_message;
	string str;//empty string
	ostringstream sout;
	int length = sizeof(mac_header) + sizeof(ip_header);
	mh = (mac_header*)pkt_data;
	ih = (ip_header*)(pkt_data + sizeof(mac_header));
	for (int i = 0; i < 5; i++)
		sout << hex << (int)(mh->dest_addr[i]) << "-";
	sout << (int)(mh->dest_addr[5]) << ",";
	for (int i = 0; i < 3; i++)
		sout << dec << (int)(ih->daddr[i]) << ".";
	sout << (int)(ih->daddr[3]) << ",";
	for (int i = 0; i < 5; i++)
		sout << hex << (int)(mh->src_addr[i]) << "-";
	sout << (int)(mh->src_addr[5]) << ",";
	for (int i = 0; i < 3; i++)
		sout << dec << (int)(ih->saddr[i]) << ".";
	sout << (int)(ih->saddr[3]);
	m_ip_message = sout.str();
	return m_ip_message;
}

void print(const struct pcap_pkthdr* header, string m_ip_message, const u_char* pkt_data)
{
	mac_header* mh;
	ip_header* ih;
	mh = (mac_header*)pkt_data;
	ih = (ip_header*)(pkt_data + sizeof(mac_header));
	tcp_header* th;
	th = (tcp_header*)(pkt_data + 34);
	cnt++;
	cout << "No." << cnt << endl;
	time_t tt = time(NULL);
	tm* t = localtime(&tt);

	cout << "Time:";
	printf("%d:%d:%d(%d)", t->tm_hour, t->tm_min, t->tm_sec, header->ts.tv_usec);
	cout << endl;

	cout << "Դ�˿ڣ�" << ntohs(th->sport) << endl;
	cout << "Ŀ�Ķ˿ڣ�" << ntohs(th->dport) << endl;
	u_short server = 21;//�������Ķ˿�
	if (ntohs(th->dport) == server)
		cout << "ftp:client->server" << endl;
	else
		cout << "ftp:server->client" << endl;
	cout << "SRC MAC ";
	for (int i = 0; i < 5; i++) {//ԴMAC��ַ
		printf("%02X-", mh->src_addr[i]);
	}
	printf("%02X,", mh->src_addr[5]);
	cout << endl;

	cout << "SRC IP ";
	for (int i = 0; i < 3; i++) {//ԴIP��ַ
		printf("%d.", ih->saddr[i]);
	}
	//fprintf_s(file, "%d,", ih->saddr[3]);
	printf("%d,", ih->saddr[3]);
	cout << endl;

	cout << "DEST MAC ";
	for (int i = 0; i < 5; i++) {//Ŀ��MAC��ַ
		printf("%02X-", mh->dest_addr[i]);
	}
	printf("%02X,", mh->dest_addr[5]);
	cout << endl;

	cout << "DEST IP ";
	for (int i = 0; i < 3; i++) {//Ŀ��IP��ַ
		printf("%d.", ih->daddr[i]);
	}
	printf("%d,", ih->daddr[3]);
	cout << endl;
	u_char flags = *((char*)th+13);
	printf("��־λ��\n");
	bool URG = flags & 0x20;
	bool ACK = flags & 0x10;
	bool PSH = flags & 0x08;
	bool RST = flags & 0x04;
	bool SYN = flags & 0x02;
	bool FIN = flags & 0x01;
	printf("URG=%d\tACK=%d\tPSH=%d\tRST=%d\tSYN=%d\tFIN=%d\n", URG, ACK, PSH, RST, SYN, FIN);

	if (SYN)
		printf("����\n");
	else if (FIN)
		printf("����\n");
	else if (ACK && !URG && !PSH && !RST && !SYN && !FIN)
		printf("ȷ��\n");

	if(ftp[m_ip_message][0]!="")
	cout << "USER:" << ftp[m_ip_message][0] << " ";
	if (ftp[m_ip_message][1] != "")
	cout << "PASSWORD:" << ftp[m_ip_message][1] << " ";
	cout << ftp[m_ip_message][2] << endl;
	ftp.erase(m_ip_message);
	cout << endl;
}
