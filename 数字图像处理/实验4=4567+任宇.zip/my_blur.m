function [] = my_blur()
    % 参数
    T = 1.2;    % 模糊长度
    a = 0.08;   % 水平模糊
    b = 0.05;   % 垂直模糊

    % 读取图像
    image_path = './cover.tif';
    img = imread(image_path);
    img = im2double(img);  
    
    % 创建频率矩阵
    [M, N, ~] = size(img);
    [U, V] = meshgrid(1:N, 1:M);
    U = U - ceil(N/2);
    V = V - ceil(M/2);
    
    % 计算H(u,v)
    D = pi * (U*a + V*b);
    H = (T ./ D) .* sin(D) .* exp(-1i * D);
    H(D == 0) = T;
    
    % 对图像进行傅里叶变换
    F_img = fft2(img);
    F_img = fftshift(F_img);

    % 运动模糊
    blurred_img = ifftshift(F_img .* H);
    blurred_img = ifft2(blurred_img);
    blurred_img = real(blurred_img); 

    % 添加高斯噪声
    noise_img = imnoise(img, 'gaussian', 0, 0.01);  
    blurred_noisy_img = imnoise(blurred_img, 'gaussian', 0, 0.01);

    % 显示结果
    figure;
    subplot(2,2,1); imshow(img); title('原始图像');
    subplot(2,2,2); imshow(blurred_img); title('运动模糊图像');
    subplot(2,2,3); imshow(noise_img); title('添加高斯噪声的图像');
    subplot(2,2,4); imshow(blurred_noisy_img); title('模糊且加噪的图像');
end
