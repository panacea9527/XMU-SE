function F = my_DFT(fp)
    % 获取输入图像的尺寸
    [M, N] = size(fp);
    F = zeros(M, N);
    
    % 对每行应用一维FFT
    for u = 1:M
        F(u, :) = fft(fp(u, :));
    end
    
    % 对每列的结果应用一维FFT
    for v = 1:N
        F(:, v) = fft(F(:, v));
    end
end

%暴力算法，运算时间太久了
% function F = my_DFT(fp)
%    [M, N] = size(fp);
%     F = zeros(M, N);
%     for u = 1:M
%         for v = 1:N
%             sum = 0;
%             for x = 1:M
%                 for y = 1:N
%                     sum = sum + double(fp(x, y)) * exp(-2i * pi * ((u-1)*(x-1)/M + (v-1)*(y-1)/N));
%                 end
%             end
%             F(u, v) = sum;
%         end
%     end
% end

