function my_Laplacian(image_path)
    % 读入图像
    original_image = imread(image_path);
    
    % 转换为灰度图
    if size(original_image, 3) == 3
        gray_image = rgb2gray(original_image);
    else
        gray_image = original_image;
    end
    
    % 定义拉普拉斯模板
    Laplacian_mask = [0     -1      0; 
                     -1     4       -1;
                      0     -1      0];
    
    % 对原始图像进行边缘填充
    pad_size = floor(size(Laplacian_mask, 1) / 2);
    padded_image = padarray(double(gray_image), [pad_size pad_size], 'replicate', 'both');
    
    % 调用卷积函数以应用拉普拉斯模板
    contours = my_conv(padded_image, Laplacian_mask);
    contours = contours(1:size(gray_image, 1), 1:size(gray_image, 2));
    sharpened_image = double(gray_image) + contours;
    sharpened_image = uint8(max(min(sharpened_image, 255), 0));
    contours_display = uint8(contours);

    % 显示原图、轮廓图和锐化后的图像
    figure;
    subplot(1, 3, 1);
    imshow(original_image);
    title('原图');

    subplot(1, 3, 2);
    imshow(contours_display);
    title('轮廓');

    subplot(1, 3, 3);
    imshow(sharpened_image);
    title('拉普拉斯算子锐化后');
end
