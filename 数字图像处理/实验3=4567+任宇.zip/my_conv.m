function result = my_conv(f, w)
    % 获取图像和滤波器的尺寸
    [fh, fw] = size(f);
    [wh, ww] = size(w);
    
    % 初始化卷积结果矩阵
    result = zeros(fh-wh+1, fw-ww+1);
    
    % 进行卷积操作
    for i = 1:size(result, 1)
        for j = 1:size(result, 2)
            % 提取当前位置的子矩阵
            sub_f = f(i:i+wh-1, j:j+ww-1);
            % 计算当前位置的卷积结果
            result(i, j) = sum(sum(double(sub_f) .* double(w)));
        end
    end
end



