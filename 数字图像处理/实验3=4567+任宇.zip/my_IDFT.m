function gp = my_IDFT(G)
    % 获取输入频谱的尺寸
    [M, N] = size(G);
    gp = zeros(M, N);
    
    % 对每列应用一维逆FFT
    for v = 1:N
        gp(:, v) = ifft(G(:, v));
    end

    % 对每行的结果应用一维逆FFT
    for u = 1:M
        gp(u, :) = ifft(gp(u, :));
    end
end

% 暴力
% function gp = my_IDFT(G)
%     [M, N] = size(G);
%     gp = zeros(M, N);
%     for x = 1:M
%         for y = 1:N
%             sum = 0;
%             for u = 1:M
%                 for v = 1:N
%                     sum = sum + G(u, v) * exp(2i * pi * ((u-1)*(x-1)/M + (v-1)*(y-1)/N));
%                 end
%             end
%             gp(x, y) = sum / (M * N);
%         end
%     end
% end

