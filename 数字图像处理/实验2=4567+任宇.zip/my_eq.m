function eq_img = my_eq(source_img)
    % 读取图像
    source_img = imread(source_img);

     % 计算图像的直方图
    [hist_counts, ~] = imhist(source_img);
    num_pixels = numel(source_img);

    % 计算累积分布函数（CDF）
    cdf = cumsum(hist_counts) / num_pixels;

    % 均衡化映射
    hist_eq_map = uint8(255 * cdf);
    eq_img = hist_eq_map(double(source_img) + 1);

    % 显示结果
    figure(1)
    % uint8函数：把参数转换为无符号数
    subplot(121),imshow(uint8(source_img)),title('原始图像');
    subplot(122),imshow(uint8(eq_img)),title('直方图均衡后的图像');

    figure(2)
    % imhist函数：显示图像的灰度直方图
    subplot(121),imhist(source_img,64),title('原始直方图');
    subplot(122),imhist(eq_img,64),title('处理后的直方图');
end
