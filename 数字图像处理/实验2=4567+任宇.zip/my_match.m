function my_match(source_img, target_img)
    % 读取图像
    source_img = imread(source_img);
    target_img = imread(target_img);
    
    % 计算原始图像的累积直方图
    [cdf_source, ~] = imhist(source_img);
    cdf_source = cumsum(cdf_source) / numel(source_img);

    % 计算目标图像的累积直方图
    [cdf_target, bins] = imhist(target_img);
    cdf_target = cumsum(cdf_target) / numel(target_img);

    % 在原始和目标直方图的等值处，找到原始和目标像素值的映射关系，完成匹配
    map = zeros(256,1,'uint8'); 
    for index = 1 : 256
        [~, minIndex] = min(abs(cdf_source(index) - cdf_target));
        map(index) = bins(minIndex);
    end
    matched_img = map(double(source_img)+1);

    % 显示结果
    figure;
    subplot(2,3,1), imshow(source_img), title('原图');
    subplot(2,3,4), imhist(source_img), title('原图的直方图');
    subplot(2,3,2), imshow(target_img), title('匹配图');
    subplot(2,3,5), imhist(target_img), title('匹配图的直方图');
    subplot(2,3,3), imshow(matched_img), title('匹配后的新图');
    subplot(2,3,6), imhist(matched_img), title('匹配后的新图的直方图');
end