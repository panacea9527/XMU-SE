% 读取载体图像和水印图像
cover = imread('cover.png');
watermark = imread('watermark.png'); 
[cover_height, cover_width, cover_channels] = size(cover);
[watermark_height, watermark_width, ~] = size(watermark);
% 调整水印图像大小以匹配载体图像
watermark_resized = imresize(watermark, [cover_height, cover_width]);
watermarked_image = zeros(size(cover), 'like', cover);
extracted_watermark = zeros(size(watermark_resized), 'like', watermark_resized);
alpha = 0.05; % 水印强度系数

% 对每个颜色通道进行DCT变换并添加水印
for channel = 1:cover_channels
    % DCT变换
    dct_cover = dct2(cover(:, :, channel));
    dct_watermark = dct2(watermark_resized(:, :, channel));
    % 添加水印
    dct_watermarked = dct_cover + alpha * dct_watermark;
    % 逆DCT变换
    watermarked_image(:, :, channel) = idct2(dct_watermarked);
    % 提取水印
    dct_extracted = (dct_watermarked - dct_cover) / alpha;
    extracted_watermark(:, :, channel) = idct2(dct_extracted);
end

figure;
subplot(2, 2, 1);
imshow(cover);
title('载体图像');
subplot(2, 2, 2);
imshow(watermark_resized);
title('水印图像');
subplot(2, 2, 3);
imshow(watermarked_image);
title('添加水印后的图像');
subplot(2, 2, 4);
imshow(extracted_watermark, []);
title('提取出的水印');