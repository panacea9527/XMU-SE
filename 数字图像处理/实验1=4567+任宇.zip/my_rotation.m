function [] = my_rotation(file_name, rotation_degree)
    % 读取文件
    image = imread(file_name);
    % 旋转图像
    rotated_image = imrotate(image, rotation_degree);
    % 保存旋转后的图像
    imwrite(rotated_image, 'rotated_image.tif');
    % 显示旋转后的图像
    imshow(rotated_image);
end

