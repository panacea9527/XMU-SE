/*
@author：任宇
 */

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        ChargingStationManager manager = new ChargingStationManager();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n请输入命令编号：");
            System.out.println("1. 新增充电桩");
            System.out.println("2. 充电桩充电");
            System.out.println("3. 列出所有充电桩信息");
            System.out.println("4. 列出每台充电桩已充电费用");
            System.out.println("5. 将慢速充电桩收费标准上涨5%");
            System.out.println("6. 退出");
            String command = scanner.nextLine();
            switch (command) {
                case "1":
                    addStation(scanner, manager);
                    break;
                case "2":
                    manager.performRandomCharging();
                    break;
                case "3":
                    manager.printStations();
                    break;
                case "4":
                    manager.printChargingCosts();
                    break;
                case "5":
                    manager.adjustRates();
                    break;
                case "6":
                    System.out.println("退出程序.");
                    running = false;
                    break;
                default:
                    System.out.println("请输入1-6的整数.");
            }
        }
        scanner.close();
    }

    //新增充电桩，输入格式为：快充/慢充 编号 位置 最大电流 电压
    private static void addStation(Scanner scanner, ChargingStationManager manager) {
        System.out.println("请按照以下格式输入：");
        System.out.println("编号、位置、最大电流、电压");
        System.out.println("如：");
        System.out.println("快充 111 西部片区 400A 250V");
        System.out.println("慢充 222 主校区 100A 6V");
        System.out.println("其中”编号“为1-9999的整数");
        int first = 0;
        boolean running = true;
        String flag = "N";
        while (running) {
            if (flag.equals("Y")) {
                break;
            }
            else{
                if(first == 1){
                    System.out.println("请按照以下格式输入：");
                    System.out.println("编号、位置、最大电流、电压");
                    System.out.println("如：");
                    System.out.println("快充 111 西部片区 400A 250V");
                    System.out.println("慢充 222 主校区 100A 6V");
                    System.out.println("其中”编号“为1-9999的整数");
                }
                else {
                    first = 1;
                }
                String newStation = scanner.nextLine();
                String[] parts = newStation.split(" ");
                try {
                    if (parts.length != 5) {
                        throw new IllegalArgumentException("输入格式不正确，正确格式为：快充/慢充 编号 位置 最大电流 电压");
                    }
                    int id = Integer.parseInt(parts[1]);
                    if (id < 1 || id > 9999) {
                        throw new IllegalArgumentException("编号必须在1-9999之间");
                    }
                    if (parts[0].equalsIgnoreCase("快充")) {
                        //忽略400A 250V后的单位，例如A和V
                        parts[3] = parts[3].substring(0, parts[3].length() - 1);
                        parts[4] = parts[4].substring(0, parts[4].length() - 1);
                        manager.addStation(parts[0], id, parts[2], Double.parseDouble(parts[3]), Double.parseDouble(parts[4]));
                    } else if (parts[0].equalsIgnoreCase("慢充")) {
                        parts[3] = parts[3].substring(0, parts[3].length() - 1);
                        parts[4] = parts[4].substring(0, parts[4].length() - 1);
                        manager.addStation(parts[0], id, parts[2], Double.parseDouble(parts[3]), Double.parseDouble(parts[4]));
                    } else {
                        throw new IllegalArgumentException("充电桩类型应为快充或者慢充");
                    }
                    System.out.println("输入成功");
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                    System.out.println("输入不成功");
                }
            }
            //无论输入是否成功，接下来都询问用户是否结束新增，若用户输入“Y”，则显示主菜单；
            // 若用户输入其他内容，则显示输入提示让用户继续输入。
            System.out.println("是否结束新增？输入Y结束新增，输入其他任意内容则继续新增");
            flag= scanner.nextLine();
        }
    }
}






