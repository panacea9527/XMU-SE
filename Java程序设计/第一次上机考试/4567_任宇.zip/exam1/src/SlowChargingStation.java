/*
@author：任宇
 */

//慢速充电桩类
public class SlowChargingStation extends ChargingStation {
    private double rate = 1.1;  //收费标准，每度电1.1元

    //构造函数
    public SlowChargingStation(int id, String location, double maxCurrent, double v) {
        super(id, location, maxCurrent, v);
    }

    //充电
    public void charge(double kwh, double minutes){
        status = "charging";
        totalCost += kwh * rate;
    }


    //调整收费标准
    public void adjustRate(double rate) {
        this.rate *= 1+rate;
    }

    @Override
    public String toString() {
        return String.format("慢充 编号: %d, 位置: %s, 最大电流: %.2fA, 电压: %.2fKW, 状态: %s, 收费标准: %.2f元/度, 累计费用: %.2f元",
                id, location, maxCurrent, v, status, rate, totalCost);
    }
}


