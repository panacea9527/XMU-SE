/*
@author：任宇
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//充电桩管理类
public class ChargingStationManager {
    private List<ChargingStation> stations; //充电桩列表

    //构造函数
    public ChargingStationManager() {
        this.stations = new ArrayList<>();
    }

    //列出所有充电桩信息
    public void printStations() {
        for (ChargingStation station : stations) {
            System.out.println(station);
        }
    }

    //随机挑选目前1/2的设备进行充电，充电度数和时间随机（度数在10-80之间，快充的时间在20-240分钟之间）。
    public void performRandomCharging() {
        Random random = new Random();
        int half = stations.size() / 2;
        //每次随机挑选一个充电桩进行充电，将其状态改为充电中，接着随机充电，如果选到充电中的充电桩，就跳过，直到选中一半的充电桩
        for (int i = 0; i < half; i++) {
            int index = random.nextInt(stations.size());
            ChargingStation station = stations.get(index);
            if (station.status.equals("available")) {
                double kwh = random.nextInt(71) + 10;
                double minutes = random.nextInt(221) + 20;
                station.charge(kwh, minutes);
                System.out.println("编号" + station.id + "的充电桩开始充电: 充电度数" + kwh + "度, 充电时间" + minutes + "分钟.");
            } else {
                //重新选择
                i--;
            }
        }
        //充电完成后，将状态改为空闲
        for (ChargingStation station : stations) {
            if (station.status.equals("charging")) {
                station.status = "available";
            }
        }
        System.out.println("充电完成.");
    }

    //将慢速充电桩收费标准上涨5%
    public void adjustRates() {
        for (ChargingStation station : stations) {
            if (station instanceof SlowChargingStation) {
                ((SlowChargingStation) station).adjustRate(0.05);
            }
        }
        System.out.println("慢速充电桩的收费标准已调整.");
    }

    //新增充电桩
    public void addStation(String type, int id, String location, double maxCurrent, double voltage) {
        if (type.equals("快充")) {
            stations.add(new FastChargingStation(id, location, maxCurrent, voltage));
        } else if (type.equals("慢充")) {
            stations.add(new SlowChargingStation(id, location, maxCurrent, voltage));
        }
        System.out.println(type + "充电桩添加成功: 编号" + id + ", 位置" + location + ", 最大电流" + maxCurrent + "A, 电压" + voltage + "KW");
    }

    //列出每台充电桩已充电费用
    public void printChargingCosts() {
        for (ChargingStation station : stations) {
            //费用输出两位小数
            System.out.println("编号" + station.id + "的充电桩已充电费用: " + String.format("%.2f", station.totalCost) + "元");
        }
    }
}



