/*
@author：任宇
 */

//快速充电桩类
public class FastChargingStation extends ChargingStation {
    //快速充电桩的收费标准
    private double rate = 1.2;


    public FastChargingStation(int id, String location, double maxCurrent, double v) {
        super(id, location, maxCurrent, v);
    }

    //充电
    public void charge(double kwh, double minutes){
        status = "charging";
        totalCost += kwh * rate + Math.ceil(minutes / 20); //快充每20分钟收费1元，不足20分钟按20分钟计费，1.2元/度
    }

    @Override
    public String toString() {
        return String.format("快充 编号: %d, 位置: %s, 最大电流: %.2fA, 电压: %.2fKW, 状态: %s, 收费标准: %.2f元/度, 累计费用: %.2f元",
                id, location, maxCurrent, v, status, rate, totalCost);
    }
}

