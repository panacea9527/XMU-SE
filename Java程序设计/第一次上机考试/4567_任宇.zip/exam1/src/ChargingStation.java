/*
@author：任宇
 */

//抽象类ChargingStation
public abstract class ChargingStation {
    protected int id;               //编号
    protected String location;      //位置
    protected double maxCurrent;    //最大电流
    protected double v;             //电压
    protected String status;        //状态
    protected double totalCost;     //累计费用

    public ChargingStation(int id, String location, double maxCurrent, double v) {
        this.id = id;
        this.location = location;
        this.maxCurrent = maxCurrent;
        this.v = v;
        this.status = "available";
        this.totalCost = 0.0;
    }

    //实现充电方法
    public abstract void charge(double kwh, double minutes);

    @Override
    public String toString() {
        return String.format("编号: %d, 位置: %s, 最大电流: %.2fA, 电压: %.2fKW, 状态: %s, 累计费用: %.2f元",
                id, location, maxCurrent, v, status, totalCost);
    }

    //getter
    public int getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public double getMaxCurrent() {
        return maxCurrent;
    }

    public double getV() {
        return v;
    }

    public String getStatus() {
        return status;
    }

    public double getTotalCost() {
        return totalCost;
    }

    //setter

    public void setId(int id) {
        this.id = id;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setMaxCurrent(double maxCurrent) {
        this.maxCurrent = maxCurrent;
    }

    public void setV(double v) {
        this.v = v;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
}


